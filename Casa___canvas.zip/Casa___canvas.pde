void setup() {
  size(800, 600);
}

void draw() {
  background(100, 170, 230);

  dibujarSuelo();
  dibujarCasa(width*0.4, height*0.5);
}

// piso
void dibujarSuelo() {
  fill(100, 200, 100);
   rect(0, height*0.85, width, height*0.15);
}

// casa
void dibujarCasa(float x, float y) {
 float ancho = width*0.45;
  float alto = height*0.35;


 fill(255); 
 rect(x, y, ancho, alto);

  // techo
 fill(200, 0, 0);
  triangle(x, y, x + ancho, y, x + ancho/2, y - alto*0.5);

  // puerta
  fill(120, 70, 40);
  rect(x + ancho*0.4, y + alto*0.5, ancho*0.2, alto*0.5);

  // ventana
  fill(200
    );
  rect(x + ancho*0.1, y + alto*0.2, ancho*0.2, alto*0.2);
}
